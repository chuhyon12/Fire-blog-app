export const config = { maxDuration: 60 };

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { apiKey, topic, target, style, length, emphasis } = req.body;

  if (!apiKey || !apiKey.startsWith('sk-ant')) {
    return res.status(401).json({ error: 'API 키가 올바르지 않아요' });
  }

  const prompt = `당신은 소방점검 업체 10년 경력의 소방시설관리사이자 인기 네이버 블로거입니다.
실무 경험을 바탕으로 독자가 끝까지 읽고 싶은 블로그 포스팅을 작성해주세요.

[주제] ${topic}
[타겟 독자] ${target}
[글 형식] ${style}
[글 길이] ${length}
${emphasis ? `[강조 포인트] ${emphasis}` : ''}

작성 규칙:
1. 첫 문단: 독자 공감 또는 충격적 사실로 시작하는 훅(hook)
2. 소제목은 ## 으로 구분
3. 법적 기준·수치 반드시 포함 (MPa, ㎡, 개수, 주기, 금액 등)
4. 현장 실제 사례나 흔한 실수 포함
5. 💡TIP: 형식으로 실천 팁 박스 1~3개 포함
6. ⚠️주의: 형식으로 경고 내용 포함
7. 마지막: 전문가 한마디 + 공감/댓글 유도 마무리
8. 글 완성 후 반드시 아래 구분자와 함께:

---META---
해시태그: #소방 #소방점검 (15개)
요약: (핵심을 50자 이내로)
SEO키워드: 키워드1, 키워드2, 키워드3, 키워드4, 키워드5`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        messages: [{ role: 'user', content: prompt }]
      }),
    });

    const data = await response.json();

    if (data.error) {
      return res.status(400).json({ error: data.error.message });
    }

    const text = data.content?.[0]?.text || '';
    return res.status(200).json({ text });

  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
